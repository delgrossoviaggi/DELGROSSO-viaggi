# DELGROSSO VIAGGI - PULIZIA ROOT SITO
# NON TOCCA GESTIONALE/ e .git/
# Crea prima un backup locale della root.
#
# ESECUZIONE:
# powershell -ExecutionPolicy Bypass -File .\PULIZIA_SITO_DELGROSSO.ps1

$ErrorActionPreference = "Stop"
$Root = (Get-Location).Path
$Gestionale = Join-Path $Root "GESTIONALE"
$Git = Join-Path $Root ".git"
$ScriptName = $MyInvocation.MyCommand.Name

Write-Host "`n=== DELGROSSO VIAGGI - PULIZIA ROOT ===" -ForegroundColor Cyan

if (-not (Test-Path $Git)) {
    Write-Host "ERRORE: esegui lo script nella ROOT del repository Git." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $Gestionale)) {
    Write-Host "ERRORE DI SICUREZZA: GESTIONALE/ non trovato. Nessun file sara' cancellato." -ForegroundColor Red
    exit 1
}

Write-Host "`nSaranno rimossi i vecchi file/cartelle della ROOT."
Write-Host "RESTANO INTEGRO: .git/ e GESTIONALE/" -ForegroundColor Green
Write-Host "Nessuna modifica a Supabase verra' eseguita."
$answer = Read-Host "`nScrivi ELIMINA per confermare"

if ($answer -cne "ELIMINA") {
    Write-Host "Operazione annullata." -ForegroundColor Yellow
    exit 0
}

# Backup completo di cio' che verra' eliminato
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Backup = Join-Path $Root "_BACKUP_PRIMA_PULIZIA_$stamp"
New-Item -ItemType Directory -Path $Backup | Out-Null

Write-Host "`nCreo backup: $Backup" -ForegroundColor Cyan

Get-ChildItem -LiteralPath $Root -Force |
    Where-Object { $_.Name -notin @(".git","GESTIONALE",$ScriptName) } |
    ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Backup -Recurse -Force
    }

# Pulizia
Write-Host "`nElimino i vecchi file..." -ForegroundColor Cyan

Get-ChildItem -LiteralPath $Root -Force |
    Where-Object { $_.Name -notin @(".git","GESTIONALE",$ScriptName) } |
    ForEach-Object {
        Write-Host "  - $($_.Name)"
        Remove-Item -LiteralPath $_.FullName -Recurse -Force
    }

Write-Host "`n=== PULIZIA COMPLETATA ===" -ForegroundColor Green
Write-Host "GESTIONALE/ intatto."
Write-Host ".git/ intatto."
Write-Host "Backup: $Backup"
Write-Host "`nNON e' stato fatto alcun commit o push." -ForegroundColor Yellow
